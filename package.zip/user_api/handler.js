const { Client } = require("pg");

const client = new Client({
  host: process.env.RDS_POSTGRES_ENDPOINT,
  port: process.env.RDS_POSTGRES_PORT,
  user: process.env.RDS_POSTGRES_USERNAME,
  password: process.env.RDS_POSTGRES_PASSWORD,
  database: process.env.RDS_DATABASE_NAME,
});

client.connect();

module.exports.handler = async (event) => {
  try {
    let result;
    const { user_id, content_id } = event.pathParameters || {};

    switch (event.httpMethod) {
      case "GET":
        // result = await client.query('SELECT * FROM favorites WHERE user_id = $1 AND content_id = $2', [user_id, content_id]);

        return {
          statusCode: 200,
          body: "HELLO WORLD",
        };
        break;
      case "POST":
        const {
          user_id: newUserId,
          content_id: newContentId,
          timestamp,
        } = JSON.parse(event.body);
        result = await client.query(
          "INSERT INTO favorites (user_id, content_id, timestamp) VALUES ($1, $2, $3) RETURNING *",
          [newUserId, newContentId, timestamp]
        );
        break;
      case "PUT":
        const { newTimestamp } = JSON.parse(event.body);
        result = await client.query(
          "UPDATE favorites SET timestamp = $3 WHERE user_id = $1 AND content_id = $2 RETURNING *",
          [user_id, content_id, newTimestamp]
        );
        break;
      case "DELETE":
        result = await client.query(
          "DELETE FROM favorites WHERE user_id = $1 AND content_id = $2 RETURNING *",
          [user_id, content_id]
        );
        break;
      default:
        throw new Error(`Unsupported method: ${event.httpMethod}`);
    }

    return {
      statusCode: 200,
      body: JSON.stringify(result.rows),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Internal Server Error" }),
    };
  }
};
